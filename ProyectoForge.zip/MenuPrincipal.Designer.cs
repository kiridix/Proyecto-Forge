﻿namespace $safeprojectname$
{
    partial class MenuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PanelMenu = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.Line2 = new System.Windows.Forms.Button();
            this.Line1 = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnCrear = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.btnEntrevistas = new System.Windows.Forms.Button();
            this.btnCurriculums = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnPostulantes = new System.Windows.Forms.Button();
            this.PanelHeader = new System.Windows.Forms.Panel();
            this.TabMain = new System.Windows.Forms.TabControl();
            this.AltaSolicitudEmpresa = new System.Windows.Forms.TabPage();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.BajaSolicitudEmpresa = new System.Windows.Forms.TabPage();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel22 = new System.Windows.Forms.Panel();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.panel18 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.buttonASolicitudAceptar = new System.Windows.Forms.Button();
            this.comboBoxASolicitudConocimientos = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxASolicitudMinimo = new System.Windows.Forms.TextBox();
            this.textBoxASolicitudNombreSolicitud = new System.Windows.Forms.TextBox();
            this.textBoxASolicitudNombreE = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBoxASolicitudEstudios = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.radioButtonSolicitudInternacional = new System.Windows.Forms.RadioButton();
            this.radioButtonSolicitudNacional = new System.Windows.Forms.RadioButton();
            this.comboBoxASolicitudCondicion = new System.Windows.Forms.ComboBox();
            this.textBoxASolicitudMaximo = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.PanelMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.TabMain.SuspendLayout();
            this.AltaSolicitudEmpresa.SuspendLayout();
            this.BajaSolicitudEmpresa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel30.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // PanelMenu
            // 
            this.PanelMenu.BackColor = System.Drawing.Color.WhiteSmoke;
            this.PanelMenu.Controls.Add(this.button10);
            this.PanelMenu.Controls.Add(this.Line2);
            this.PanelMenu.Controls.Add(this.Line1);
            this.PanelMenu.Controls.Add(this.btnModificar);
            this.PanelMenu.Controls.Add(this.btnEliminar);
            this.PanelMenu.Controls.Add(this.btnCrear);
            this.PanelMenu.Controls.Add(this.button1);
            this.PanelMenu.Controls.Add(this.picLogo);
            this.PanelMenu.Controls.Add(this.btnEntrevistas);
            this.PanelMenu.Controls.Add(this.btnCurriculums);
            this.PanelMenu.Controls.Add(this.panel2);
            this.PanelMenu.Controls.Add(this.btnPostulantes);
            this.PanelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelMenu.Location = new System.Drawing.Point(0, 0);
            this.PanelMenu.Name = "PanelMenu";
            this.PanelMenu.Size = new System.Drawing.Size(215, 652);
            this.PanelMenu.TabIndex = 3;
            this.PanelMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelMenu_Paint);
            this.PanelMenu.MouseHover += new System.EventHandler(this.PanelMenu_MouseHover);
            // 
            // button10
            // 
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Image = global::$safeprojectname$.Properties.Resources.icons8_New_Message_50;
            this.button10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button10.Location = new System.Drawing.Point(7, 292);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(202, 52);
            this.button10.TabIndex = 29;
            this.button10.Text = "Solicitudes";
            this.button10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // Line2
            // 
            this.Line2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Line2.FlatAppearance.BorderSize = 0;
            this.Line2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.Line2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Line2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Line2.Location = new System.Drawing.Point(7, 573);
            this.Line2.Name = "Line2";
            this.Line2.Size = new System.Drawing.Size(200, 2);
            this.Line2.TabIndex = 28;
            this.Line2.UseVisualStyleBackColor = true;
            // 
            // Line1
            // 
            this.Line1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Line1.FlatAppearance.BorderSize = 0;
            this.Line1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.Line1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Line1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Line1.Location = new System.Drawing.Point(7, 472);
            this.Line1.Name = "Line1";
            this.Line1.Size = new System.Drawing.Size(200, 2);
            this.Line1.TabIndex = 27;
            this.Line1.UseVisualStyleBackColor = true;
            // 
            // btnModificar
            // 
            this.btnModificar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnModificar.FlatAppearance.BorderSize = 0;
            this.btnModificar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModificar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificar.Location = new System.Drawing.Point(7, 542);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(200, 25);
            this.btnModificar.TabIndex = 26;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = true;
            // 
            // btnEliminar
            // 
            this.btnEliminar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnEliminar.FlatAppearance.BorderSize = 0;
            this.btnEliminar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEliminar.Location = new System.Drawing.Point(9, 509);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(200, 25);
            this.btnEliminar.TabIndex = 25;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.button6_Click);
            // 
            // btnCrear
            // 
            this.btnCrear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCrear.FlatAppearance.BorderSize = 0;
            this.btnCrear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCrear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCrear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCrear.Location = new System.Drawing.Point(9, 476);
            this.btnCrear.Name = "btnCrear";
            this.btnCrear.Size = new System.Drawing.Size(200, 25);
            this.btnCrear.TabIndex = 23;
            this.btnCrear.Text = "Crear";
            this.btnCrear.UseVisualStyleBackColor = true;
            this.btnCrear.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // button1
            // 
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = global::$safeprojectname$.Properties.Resources.icons8_Exit_50;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(6, 593);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(203, 50);
            this.button1.TabIndex = 21;
            this.button1.Text = "Salir";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // picLogo
            // 
            this.picLogo.Image = global::$safeprojectname$.Properties.Resources.fb_forge;
            this.picLogo.Location = new System.Drawing.Point(0, 14);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(215, 86);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picLogo.TabIndex = 4;
            this.picLogo.TabStop = false;
            this.picLogo.Visible = false;
            // 
            // btnEntrevistas
            // 
            this.btnEntrevistas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnEntrevistas.FlatAppearance.BorderSize = 0;
            this.btnEntrevistas.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnEntrevistas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnEntrevistas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnEntrevistas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEntrevistas.Image = global::$safeprojectname$.Properties.Resources.icons8_Profile_50;
            this.btnEntrevistas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEntrevistas.Location = new System.Drawing.Point(9, 168);
            this.btnEntrevistas.Name = "btnEntrevistas";
            this.btnEntrevistas.Size = new System.Drawing.Size(200, 52);
            this.btnEntrevistas.TabIndex = 3;
            this.btnEntrevistas.Text = "Entrevistas";
            this.btnEntrevistas.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEntrevistas.UseVisualStyleBackColor = true;
            this.btnEntrevistas.Click += new System.EventHandler(this.btnEntrevistas_Click);
            this.btnEntrevistas.MouseHover += new System.EventHandler(this.btnEntrevistas_MouseHover);
            // 
            // btnCurriculums
            // 
            this.btnCurriculums.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCurriculums.FlatAppearance.BorderSize = 0;
            this.btnCurriculums.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCurriculums.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCurriculums.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnCurriculums.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCurriculums.Image = global::$safeprojectname$.Properties.Resources.icons8_Resume_50;
            this.btnCurriculums.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCurriculums.Location = new System.Drawing.Point(9, 231);
            this.btnCurriculums.Name = "btnCurriculums";
            this.btnCurriculums.Size = new System.Drawing.Size(200, 52);
            this.btnCurriculums.TabIndex = 2;
            this.btnCurriculums.Text = "Curriculums";
            this.btnCurriculums.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCurriculums.UseVisualStyleBackColor = true;
            this.btnCurriculums.Click += new System.EventHandler(this.btnCurriculums_Click);
            this.btnCurriculums.MouseHover += new System.EventHandler(this.btnCurriculums_MouseHover);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(215, 8);
            this.panel2.TabIndex = 1;
            // 
            // btnPostulantes
            // 
            this.btnPostulantes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPostulantes.FlatAppearance.BorderSize = 0;
            this.btnPostulantes.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnPostulantes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnPostulantes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnPostulantes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPostulantes.Image = global::$safeprojectname$.Properties.Resources.icons8_User_50;
            this.btnPostulantes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPostulantes.Location = new System.Drawing.Point(6, 106);
            this.btnPostulantes.Name = "btnPostulantes";
            this.btnPostulantes.Size = new System.Drawing.Size(203, 56);
            this.btnPostulantes.TabIndex = 0;
            this.btnPostulantes.Text = "Postulantes";
            this.btnPostulantes.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPostulantes.UseVisualStyleBackColor = true;
            this.btnPostulantes.Click += new System.EventHandler(this.btnPostulantes_Click);
            this.btnPostulantes.MouseHover += new System.EventHandler(this.btnPostulantes_MouseHover);
            // 
            // PanelHeader
            // 
            this.PanelHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.PanelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelHeader.Location = new System.Drawing.Point(215, 0);
            this.PanelHeader.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.PanelHeader.Name = "PanelHeader";
            this.PanelHeader.Size = new System.Drawing.Size(694, 8);
            this.PanelHeader.TabIndex = 5;
            // 
            // TabMain
            // 
            this.TabMain.Controls.Add(this.AltaSolicitudEmpresa);
            this.TabMain.Controls.Add(this.BajaSolicitudEmpresa);
            this.TabMain.Controls.Add(this.tabPage1);
            this.TabMain.Controls.Add(this.tabPage2);
            this.TabMain.Controls.Add(this.tabPage3);
            this.TabMain.Controls.Add(this.tabPage4);
            this.TabMain.Location = new System.Drawing.Point(61, -22);
            this.TabMain.Multiline = true;
            this.TabMain.Name = "TabMain";
            this.TabMain.SelectedIndex = 0;
            this.TabMain.Size = new System.Drawing.Size(858, 676);
            this.TabMain.TabIndex = 20;
            this.TabMain.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabControl1_MouseClick);
            // 
            // AltaSolicitudEmpresa
            // 
            this.AltaSolicitudEmpresa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AltaSolicitudEmpresa.Controls.Add(this.button2);
            this.AltaSolicitudEmpresa.Controls.Add(this.button4);
            this.AltaSolicitudEmpresa.Controls.Add(this.panel23);
            this.AltaSolicitudEmpresa.Controls.Add(this.panel24);
            this.AltaSolicitudEmpresa.Controls.Add(this.panel25);
            this.AltaSolicitudEmpresa.Controls.Add(this.panel29);
            this.AltaSolicitudEmpresa.Controls.Add(this.button5);
            this.AltaSolicitudEmpresa.Controls.Add(this.dataGridView2);
            this.AltaSolicitudEmpresa.Controls.Add(this.dataGridView1);
            this.AltaSolicitudEmpresa.Controls.Add(this.comboBox1);
            this.AltaSolicitudEmpresa.Controls.Add(this.label15);
            this.AltaSolicitudEmpresa.Controls.Add(this.comboBoxASolicitudEstudios);
            this.AltaSolicitudEmpresa.Controls.Add(this.label16);
            this.AltaSolicitudEmpresa.Controls.Add(this.radioButtonSolicitudInternacional);
            this.AltaSolicitudEmpresa.Controls.Add(this.radioButtonSolicitudNacional);
            this.AltaSolicitudEmpresa.Controls.Add(this.comboBoxASolicitudCondicion);
            this.AltaSolicitudEmpresa.Controls.Add(this.textBoxASolicitudMaximo);
            this.AltaSolicitudEmpresa.Controls.Add(this.textBox9);
            this.AltaSolicitudEmpresa.Controls.Add(this.textBox10);
            this.AltaSolicitudEmpresa.Controls.Add(this.textBox11);
            this.AltaSolicitudEmpresa.Controls.Add(this.label17);
            this.AltaSolicitudEmpresa.Controls.Add(this.label18);
            this.AltaSolicitudEmpresa.Controls.Add(this.label19);
            this.AltaSolicitudEmpresa.Controls.Add(this.label20);
            this.AltaSolicitudEmpresa.Controls.Add(this.label21);
            this.AltaSolicitudEmpresa.Controls.Add(this.richTextBox1);
            this.AltaSolicitudEmpresa.Location = new System.Drawing.Point(4, 25);
            this.AltaSolicitudEmpresa.Name = "AltaSolicitudEmpresa";
            this.AltaSolicitudEmpresa.Padding = new System.Windows.Forms.Padding(3);
            this.AltaSolicitudEmpresa.Size = new System.Drawing.Size(850, 647);
            this.AltaSolicitudEmpresa.TabIndex = 0;
            this.AltaSolicitudEmpresa.Text = "Alta de solicitud de empresa";
            this.AltaSolicitudEmpresa.Click += new System.EventHandler(this.tabPage1_Click);
            this.AltaSolicitudEmpresa.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabPage1_MouseClick);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(100, 96);
            this.richTextBox1.TabIndex = 32;
            this.richTextBox1.Text = "";
            // 
            // BajaSolicitudEmpresa
            // 
            this.BajaSolicitudEmpresa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BajaSolicitudEmpresa.Controls.Add(this.panel14);
            this.BajaSolicitudEmpresa.Controls.Add(this.panel13);
            this.BajaSolicitudEmpresa.Controls.Add(this.panel12);
            this.BajaSolicitudEmpresa.Controls.Add(this.button3);
            this.BajaSolicitudEmpresa.Controls.Add(this.dataGridView3);
            this.BajaSolicitudEmpresa.Controls.Add(this.textBox3);
            this.BajaSolicitudEmpresa.Controls.Add(this.textBox2);
            this.BajaSolicitudEmpresa.Controls.Add(this.textBox1);
            this.BajaSolicitudEmpresa.Controls.Add(this.label11);
            this.BajaSolicitudEmpresa.Controls.Add(this.label10);
            this.BajaSolicitudEmpresa.Controls.Add(this.label9);
            this.BajaSolicitudEmpresa.Location = new System.Drawing.Point(4, 25);
            this.BajaSolicitudEmpresa.Name = "BajaSolicitudEmpresa";
            this.BajaSolicitudEmpresa.Padding = new System.Windows.Forms.Padding(3);
            this.BajaSolicitudEmpresa.Size = new System.Drawing.Size(850, 647);
            this.BajaSolicitudEmpresa.TabIndex = 1;
            this.BajaSolicitudEmpresa.Text = "Baja de solicitud de empresa";
            this.BajaSolicitudEmpresa.Click += new System.EventHandler(this.BajaSolicitudEmpresa_Click);
            this.BajaSolicitudEmpresa.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabPage2_MouseClick);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.White;
            this.panel14.Location = new System.Drawing.Point(397, 82);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(213, 2);
            this.panel14.TabIndex = 12;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Location = new System.Drawing.Point(397, 158);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(213, 2);
            this.panel13.TabIndex = 11;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.Location = new System.Drawing.Point(397, 120);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(213, 2);
            this.panel12.TabIndex = 10;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(340, 432);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(110, 24);
            this.button3.TabIndex = 9;
            this.button3.Text = "Eliminar";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(157, 194);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(589, 194);
            this.dataGridView3.TabIndex = 8;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Location = new System.Drawing.Point(397, 138);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(212, 15);
            this.textBox3.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Location = new System.Drawing.Point(397, 100);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(212, 15);
            this.textBox2.TabIndex = 5;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Location = new System.Drawing.Point(397, 62);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(212, 15);
            this.textBox1.TabIndex = 4;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(150, 140);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 20);
            this.label11.TabIndex = 3;
            this.label11.Text = "R.U.T*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(150, 102);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(154, 20);
            this.label10.TabIndex = 2;
            this.label10.Text = "Nombre de solicitud*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(150, 66);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(163, 20);
            this.label9.TabIndex = 1;
            this.label9.Text = "Nombre de empresa *";
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(850, 647);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click_1);
            this.tabPage1.MouseHover += new System.EventHandler(this.tabPage1_MouseHover);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Consolas", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(246, 211);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(495, 64);
            this.label5.TabIndex = 0;
            this.label5.Text = "Bienvenido al sistema de gestion\r\n de solicitudes y curriculums";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Gainsboro;
            this.tabPage2.Controls.Add(this.panel22);
            this.tabPage2.Controls.Add(this.textBox8);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.panel21);
            this.tabPage2.Controls.Add(this.textBox7);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.panel20);
            this.tabPage2.Controls.Add(this.textBox6);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.panel19);
            this.tabPage2.Controls.Add(this.textBox5);
            this.tabPage2.Controls.Add(this.panel18);
            this.tabPage2.Controls.Add(this.textBox4);
            this.tabPage2.Controls.Add(this.panel11);
            this.tabPage2.Controls.Add(this.dateTimePicker1);
            this.tabPage2.Controls.Add(this.panel10);
            this.tabPage2.Controls.Add(this.panel6);
            this.tabPage2.Controls.Add(this.panel1);
            this.tabPage2.Controls.Add(this.buttonASolicitudAceptar);
            this.tabPage2.Controls.Add(this.comboBoxASolicitudConocimientos);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.textBoxASolicitudMinimo);
            this.tabPage2.Controls.Add(this.textBoxASolicitudNombreSolicitud);
            this.tabPage2.Controls.Add(this.textBoxASolicitudNombreE);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(850, 647);
            this.tabPage2.TabIndex = 3;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(850, 647);
            this.tabPage3.TabIndex = 4;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(850, 647);
            this.tabPage4.TabIndex = 5;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.White;
            this.panel22.Location = new System.Drawing.Point(427, 420);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(124, 2);
            this.panel22.TabIndex = 72;
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(427, 402);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(124, 19);
            this.textBox8.TabIndex = 73;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(216, 402);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 20);
            this.label14.TabIndex = 71;
            this.label14.Text = "E-mail*";
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.White;
            this.panel21.Location = new System.Drawing.Point(427, 376);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(124, 2);
            this.panel21.TabIndex = 69;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(427, 358);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(124, 19);
            this.textBox7.TabIndex = 70;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(216, 358);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(205, 20);
            this.label13.TabIndex = 68;
            this.label13.Text = "Monto del tripo de contrato*";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.White;
            this.panel20.Location = new System.Drawing.Point(427, 327);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(124, 2);
            this.panel20.TabIndex = 66;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(427, 309);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(124, 19);
            this.textBox6.TabIndex = 67;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(216, 309);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 20);
            this.label12.TabIndex = 65;
            this.label12.Text = "Nombre*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(555, 268);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(12, 16);
            this.label4.TabIndex = 64;
            this.label4.Text = "-";
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.White;
            this.panel19.Location = new System.Drawing.Point(573, 283);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(23, 2);
            this.panel19.TabIndex = 60;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.ForeColor = System.Drawing.Color.White;
            this.textBox5.Location = new System.Drawing.Point(573, 265);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(23, 19);
            this.textBox5.TabIndex = 63;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.White;
            this.panel18.Location = new System.Drawing.Point(427, 283);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(124, 2);
            this.panel18.TabIndex = 59;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(427, 265);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(124, 19);
            this.textBox4.TabIndex = 62;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Controls.Add(this.panel15);
            this.panel11.Controls.Add(this.panel17);
            this.panel11.Location = new System.Drawing.Point(428, 244);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(200, 2);
            this.panel11.TabIndex = 58;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.White;
            this.panel15.Controls.Add(this.panel16);
            this.panel15.Location = new System.Drawing.Point(0, 11);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(311, 2);
            this.panel15.TabIndex = 24;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.White;
            this.panel16.Location = new System.Drawing.Point(0, 39);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(311, 2);
            this.panel16.TabIndex = 23;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.White;
            this.panel17.Location = new System.Drawing.Point(0, 39);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(311, 2);
            this.panel17.TabIndex = 23;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(427, 223);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 61;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Location = new System.Drawing.Point(427, 206);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(124, 2);
            this.panel10.TabIndex = 57;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Controls.Add(this.panel9);
            this.panel6.Location = new System.Drawing.Point(427, 165);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(317, 2);
            this.panel6.TabIndex = 56;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Location = new System.Drawing.Point(0, 11);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(311, 2);
            this.panel7.TabIndex = 24;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Location = new System.Drawing.Point(0, 39);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(311, 2);
            this.panel8.TabIndex = 23;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Location = new System.Drawing.Point(0, 39);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(311, 2);
            this.panel9.TabIndex = 23;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Location = new System.Drawing.Point(427, 124);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(317, 2);
            this.panel1.TabIndex = 55;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(0, 11);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(311, 2);
            this.panel4.TabIndex = 24;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Location = new System.Drawing.Point(0, 39);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(311, 2);
            this.panel5.TabIndex = 23;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(0, 39);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(311, 2);
            this.panel3.TabIndex = 23;
            // 
            // buttonASolicitudAceptar
            // 
            this.buttonASolicitudAceptar.BackColor = System.Drawing.Color.White;
            this.buttonASolicitudAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonASolicitudAceptar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonASolicitudAceptar.Location = new System.Drawing.Point(427, 523);
            this.buttonASolicitudAceptar.Name = "buttonASolicitudAceptar";
            this.buttonASolicitudAceptar.Size = new System.Drawing.Size(99, 26);
            this.buttonASolicitudAceptar.TabIndex = 54;
            this.buttonASolicitudAceptar.Text = "Aceptar";
            this.buttonASolicitudAceptar.UseVisualStyleBackColor = false;
            // 
            // comboBoxASolicitudConocimientos
            // 
            this.comboBoxASolicitudConocimientos.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comboBoxASolicitudConocimientos.FormattingEnabled = true;
            this.comboBoxASolicitudConocimientos.Location = new System.Drawing.Point(704, 305);
            this.comboBoxASolicitudConocimientos.Name = "comboBoxASolicitudConocimientos";
            this.comboBoxASolicitudConocimientos.Size = new System.Drawing.Size(117, 24);
            this.comboBoxASolicitudConocimientos.TabIndex = 53;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(568, 309);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(130, 20);
            this.label8.TabIndex = 52;
            this.label8.Text = "Tipo de contrato*";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(216, 265);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 20);
            this.label7.TabIndex = 51;
            this.label7.Text = "RUT*";
            // 
            // textBoxASolicitudMinimo
            // 
            this.textBoxASolicitudMinimo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxASolicitudMinimo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxASolicitudMinimo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxASolicitudMinimo.Location = new System.Drawing.Point(427, 187);
            this.textBoxASolicitudMinimo.Name = "textBoxASolicitudMinimo";
            this.textBoxASolicitudMinimo.Size = new System.Drawing.Size(124, 19);
            this.textBoxASolicitudMinimo.TabIndex = 50;
            // 
            // textBoxASolicitudNombreSolicitud
            // 
            this.textBoxASolicitudNombreSolicitud.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxASolicitudNombreSolicitud.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxASolicitudNombreSolicitud.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxASolicitudNombreSolicitud.Location = new System.Drawing.Point(427, 144);
            this.textBoxASolicitudNombreSolicitud.Name = "textBoxASolicitudNombreSolicitud";
            this.textBoxASolicitudNombreSolicitud.Size = new System.Drawing.Size(317, 19);
            this.textBoxASolicitudNombreSolicitud.TabIndex = 49;
            this.textBoxASolicitudNombreSolicitud.Visible = false;
            // 
            // textBoxASolicitudNombreE
            // 
            this.textBoxASolicitudNombreE.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxASolicitudNombreE.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxASolicitudNombreE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxASolicitudNombreE.ForeColor = System.Drawing.Color.White;
            this.textBoxASolicitudNombreE.Location = new System.Drawing.Point(427, 103);
            this.textBoxASolicitudNombreE.Name = "textBoxASolicitudNombreE";
            this.textBoxASolicitudNombreE.Size = new System.Drawing.Size(317, 19);
            this.textBoxASolicitudNombreE.TabIndex = 48;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(216, 222);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 20);
            this.label6.TabIndex = 47;
            this.label6.Text = "Fecha de ingreso*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(216, 187);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 20);
            this.label3.TabIndex = 46;
            this.label3.Text = "Dirección fiscal*";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(216, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 20);
            this.label2.TabIndex = 45;
            this.label2.Text = "Dirección física*";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(216, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 20);
            this.label1.TabIndex = 44;
            this.label1.Text = "Rubro*";
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Image = global::$safeprojectname$.Properties.Resources.icons8_Plus_48;
            this.button2.Location = new System.Drawing.Point(844, 306);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(24, 25);
            this.button2.TabIndex = 57;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Image = global::$safeprojectname$.Properties.Resources.icons8_Plus_48;
            this.button4.Location = new System.Drawing.Point(432, 290);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(24, 25);
            this.button4.TabIndex = 56;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.White;
            this.panel23.Location = new System.Drawing.Point(626, 202);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(124, 2);
            this.panel23.TabIndex = 55;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.White;
            this.panel24.Location = new System.Drawing.Point(433, 202);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(124, 2);
            this.panel24.TabIndex = 54;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.White;
            this.panel25.Controls.Add(this.panel26);
            this.panel25.Controls.Add(this.panel28);
            this.panel25.Location = new System.Drawing.Point(433, 166);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(317, 2);
            this.panel25.TabIndex = 53;
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.White;
            this.panel26.Controls.Add(this.panel27);
            this.panel26.Location = new System.Drawing.Point(0, 11);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(311, 2);
            this.panel26.TabIndex = 24;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.White;
            this.panel27.Location = new System.Drawing.Point(0, 39);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(311, 2);
            this.panel27.TabIndex = 23;
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.White;
            this.panel28.Location = new System.Drawing.Point(0, 39);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(311, 2);
            this.panel28.TabIndex = 23;
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.White;
            this.panel29.Controls.Add(this.panel30);
            this.panel29.Controls.Add(this.panel32);
            this.panel29.Location = new System.Drawing.Point(433, 124);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(317, 2);
            this.panel29.TabIndex = 52;
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.White;
            this.panel30.Controls.Add(this.panel31);
            this.panel30.Location = new System.Drawing.Point(0, 11);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(311, 2);
            this.panel30.TabIndex = 24;
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.White;
            this.panel31.Location = new System.Drawing.Point(0, 39);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(311, 2);
            this.panel31.TabIndex = 23;
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.White;
            this.panel32.Location = new System.Drawing.Point(0, 39);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(311, 2);
            this.panel32.TabIndex = 23;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(462, 440);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(99, 26);
            this.button5.TabIndex = 51;
            this.button5.Text = "Aceptar";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(531, 326);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(306, 90);
            this.dataGridView2.TabIndex = 50;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(185, 326);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(306, 90);
            this.dataGridView1.TabIndex = 49;
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(636, 287);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(156, 24);
            this.comboBox1.TabIndex = 48;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(512, 290);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(128, 20);
            this.label15.TabIndex = 47;
            this.label15.Text = "Conocimientos: *";
            // 
            // comboBoxASolicitudEstudios
            // 
            this.comboBoxASolicitudEstudios.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comboBoxASolicitudEstudios.FormattingEnabled = true;
            this.comboBoxASolicitudEstudios.Location = new System.Drawing.Point(262, 287);
            this.comboBoxASolicitudEstudios.Name = "comboBoxASolicitudEstudios";
            this.comboBoxASolicitudEstudios.Size = new System.Drawing.Size(156, 24);
            this.comboBoxASolicitudEstudios.TabIndex = 46;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(178, 290);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(85, 20);
            this.label16.TabIndex = 45;
            this.label16.Text = "Estudios: *";
            // 
            // radioButtonSolicitudInternacional
            // 
            this.radioButtonSolicitudInternacional.AutoSize = true;
            this.radioButtonSolicitudInternacional.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonSolicitudInternacional.Location = new System.Drawing.Point(524, 251);
            this.radioButtonSolicitudInternacional.Name = "radioButtonSolicitudInternacional";
            this.radioButtonSolicitudInternacional.Size = new System.Drawing.Size(119, 24);
            this.radioButtonSolicitudInternacional.TabIndex = 44;
            this.radioButtonSolicitudInternacional.TabStop = true;
            this.radioButtonSolicitudInternacional.Text = "Internacional";
            this.radioButtonSolicitudInternacional.UseVisualStyleBackColor = true;
            // 
            // radioButtonSolicitudNacional
            // 
            this.radioButtonSolicitudNacional.AutoSize = true;
            this.radioButtonSolicitudNacional.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonSolicitudNacional.Location = new System.Drawing.Point(296, 251);
            this.radioButtonSolicitudNacional.Name = "radioButtonSolicitudNacional";
            this.radioButtonSolicitudNacional.Size = new System.Drawing.Size(88, 24);
            this.radioButtonSolicitudNacional.TabIndex = 43;
            this.radioButtonSolicitudNacional.TabStop = true;
            this.radioButtonSolicitudNacional.Text = "Nacional";
            this.radioButtonSolicitudNacional.UseVisualStyleBackColor = true;
            // 
            // comboBoxASolicitudCondicion
            // 
            this.comboBoxASolicitudCondicion.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comboBoxASolicitudCondicion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxASolicitudCondicion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxASolicitudCondicion.FormattingEnabled = true;
            this.comboBoxASolicitudCondicion.Location = new System.Drawing.Point(433, 216);
            this.comboBoxASolicitudCondicion.Name = "comboBoxASolicitudCondicion";
            this.comboBoxASolicitudCondicion.Size = new System.Drawing.Size(317, 28);
            this.comboBoxASolicitudCondicion.TabIndex = 42;
            // 
            // textBoxASolicitudMaximo
            // 
            this.textBoxASolicitudMaximo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxASolicitudMaximo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxASolicitudMaximo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxASolicitudMaximo.Location = new System.Drawing.Point(626, 182);
            this.textBoxASolicitudMaximo.Name = "textBoxASolicitudMaximo";
            this.textBoxASolicitudMaximo.Size = new System.Drawing.Size(124, 19);
            this.textBoxASolicitudMaximo.TabIndex = 41;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(433, 183);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(124, 19);
            this.textBox9.TabIndex = 40;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(433, 145);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(317, 19);
            this.textBox10.TabIndex = 39;
            this.textBox10.Visible = false;
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.ForeColor = System.Drawing.Color.White;
            this.textBox11.Location = new System.Drawing.Point(433, 103);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(317, 19);
            this.textBox11.TabIndex = 38;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(178, 219);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(185, 20);
            this.label17.TabIndex = 37;
            this.label17.Text = "Condición de empleado *";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(557, 181);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(73, 20);
            this.label18.TabIndex = 36;
            this.label18.Text = "maximo *";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(178, 181);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(182, 20);
            this.label19.TabIndex = 35;
            this.label19.Text = "Sueldo nominal minimo *";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(178, 144);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(158, 20);
            this.label20.TabIndex = 34;
            this.label20.Text = "Nombre de solicitud *";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(178, 103);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(165, 20);
            this.label21.TabIndex = 33;
            this.label21.Text = "Nombre de Empresa *";
            // 
            // MenuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(909, 652);
            this.Controls.Add(this.PanelHeader);
            this.Controls.Add(this.PanelMenu);
            this.Controls.Add(this.TabMain);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MenuPrincipal";
            this.Text = "l";
            this.Load += new System.EventHandler(this.MenuPrincipal_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.MainMenu_MouseClick);
            this.PanelMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.TabMain.ResumeLayout(false);
            this.AltaSolicitudEmpresa.ResumeLayout(false);
            this.AltaSolicitudEmpresa.PerformLayout();
            this.BajaSolicitudEmpresa.ResumeLayout(false);
            this.BajaSolicitudEmpresa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel PanelMenu;
        private System.Windows.Forms.Button btnEntrevistas;
        private System.Windows.Forms.Button btnCurriculums;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnPostulantes;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Panel PanelHeader;
        private System.Windows.Forms.TabControl TabMain;
        private System.Windows.Forms.TabPage AltaSolicitudEmpresa;
        private System.Windows.Forms.TabPage BajaSolicitudEmpresa;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnCrear;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button Line1;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button Line2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttonASolicitudAceptar;
        private System.Windows.Forms.ComboBox comboBoxASolicitudConocimientos;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxASolicitudMinimo;
        private System.Windows.Forms.TextBox textBoxASolicitudNombreSolicitud;
        private System.Windows.Forms.TextBox textBoxASolicitudNombreE;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBoxASolicitudEstudios;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RadioButton radioButtonSolicitudInternacional;
        private System.Windows.Forms.RadioButton radioButtonSolicitudNacional;
        private System.Windows.Forms.ComboBox comboBoxASolicitudCondicion;
        private System.Windows.Forms.TextBox textBoxASolicitudMaximo;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
    }
}